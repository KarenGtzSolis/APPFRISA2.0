# FrisaAppAndroid
Android app for frisa

## Getting Started
This project is a starting point for a Flutter application.
