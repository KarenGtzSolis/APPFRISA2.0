package com.example.navdrawer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.navdrawer.model.OrgRegister
import com.example.navdrawer.model.OrgRegisterResponse
import com.example.navdrawer.service.OrgService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class OrganizationViewModel : ViewModel() {
    // Instancia del servicio de organizaciones
    private val orgService = OrgService.create()

    // Función para agregar una nueva organización
    /*fun addOrganization(token: String, org: OrgRegister, onResult: (OrgRegisterResponse?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val response = orgService.addOrg(token, org)
                if (response.isSuccessful) {
                    val orgResponse = response.body()
                    onResult(orgResponse)
                } else {
                    onResult(null)
                }
            } catch (e: Exception) {
                onResult(null)
            }
        }
    }

     */

    // Función para obtener todas las organizaciones
    fun getAllOrganizations(): List<OrgRegister> {
        viewModelScope.launch {
            try {
                val response = orgService.getAllOrgs()
                if (response.isNotEmpty()) {
                     return response
                }

            } catch (e: Exception) {

            }
        }

    }
}
