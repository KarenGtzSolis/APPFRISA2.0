package com.example.navdrawer.model

data class Organization(
    val _id: String,
    val name: String,
    val phone: Int,
    val email: String,
    val street: String,
    val suburb: String,
    val city: String,
    val state: String,
    val schedule: String,
    val linkWeb: String,
    val linkFacebook: String,
    val linkInstagram: String,
    val linkTwitter: String,
    val linkOther: String,
    val description: String,
    val image: String, // URL de la imagen
    val tags: List<String>,
    val password: String,
    val __v: Int
)
