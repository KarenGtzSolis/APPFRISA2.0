package com.example.navdrawer.model

class UserProtectedResponse {
}